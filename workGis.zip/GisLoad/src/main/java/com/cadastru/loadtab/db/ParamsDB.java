package com.cadastru.loadtab.db;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.cadastru.loadtab.interfaces.ParamsDBInterf;

@Component
public class ParamsDB implements ParamsDBInterf {

	static final Logger logger = LoggerFactory.getLogger(ParamsDB.class);
	
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}
	
	public String getParams(String paramName) {
		
		String sql = "select param_value from gisadm.t_param where param_name = :t_param";
		SqlParameterSource namedParameters = new MapSqlParameterSource("t_param", paramName);
		
		return this.jdbcTemplate.queryForObject(sql, namedParameters, String.class);
	}

	public String getCountActivity() {
		String result = "0";
		String sql = "select count(*) cnt from pg_stat_activity";
		result = Integer.toString(jdbcTemplate.getJdbcOperations().queryForObject(sql, Integer.class));
		
		return result;
	}

}
