package com.cadastru.loadtab.interfaces;

public interface ParamsDBInterf {
	
	String getParams(String paramName);
	
	String getCountActivity();
}
